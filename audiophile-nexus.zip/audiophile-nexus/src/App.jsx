/**
 * App.jsx - Main application component
 */

import React, { useState, useEffect } from 'react';
import UnifiedPlayer from './services/UnifiedPlayer';
import MasterStation from './services/MasterStation';
import AudioAnalysis from './components/AudioAnalysis';
import PlaylistManager from './components/PlaylistManager';
import SourceSelector from './components/SourceSelector';

function App() {
  const [player] = useState(() => new UnifiedPlayer());
  const [masterStation] = useState(() => new MasterStation(/* database */));
  const [currentTrack, setCurrentTrack] = useState(null);
  const [queue, setQueue] = useState([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeSource, setActiveSource] = useState('spotify');

  useEffect(() => {
    // Initialize player with user credentials
    initializePlayer();
    
    // Load initial queue from MasterStation
    loadInitialQueue();
  }, []);

  const initializePlayer = async () => {
    // PSEUDOCODE: Load credentials from localStorage or API
    const credentials = {
      spotify: { accessToken: 'SPOTIFY_TOKEN' },
      youtube: { apiKey: 'YOUTUBE_API_KEY' }
    };

    await player.initializeSource(activeSource, credentials[activeSource]);
  };

  const loadInitialQueue = async () => {
    const generatedQueue = await masterStation.generateQueue(null, 50);
    setQueue(generatedQueue);
    
    if (generatedQueue.length > 0) {
      setCurrentTrack(generatedQueue[0]);
    }
  };

  const handlePlay = async (track) => {
    await player.play(track);
    setCurrentTrack(track);
    setIsPlaying(true);

    // Record listening event
    masterStation.recordListenEvent(track, 'play');
  };

  const handlePause = () => {
    player.pause();
    setIsPlaying(false);
  };

  const handleNext = async () => {
    const nextTrack = queue[queue.indexOf(currentTrack) + 1];
    if (nextTrack) {
      // Record completion of current track
      if (currentTrack) {
        masterStation.recordListenEvent(currentTrack, 'complete');
      }
      
      await handlePlay(nextTrack);
    }
  };

  const handleSkip = async () => {
    // Record skip event
    if (currentTrack) {
      masterStation.recordListenEvent(currentTrack, 'skip');
    }
    
    await handleNext();
  };

  const handleSourceChange = async (source) => {
    setActiveSource(source);
    await player.initializeSource(source);
  };

  const regenerateQueue = async () => {
    const newQueue = await masterStation.generateQueue(currentTrack, 50);
    setQueue(newQueue);
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>Audiophile Nexus</h1>
        <SourceSelector 
          activeSource={activeSource}
          onSourceChange={handleSourceChange}
        />
      </header>

      <main className="app-main">
        {/* Player Controls */}
        <div className="player-section">
          <NowPlaying track={currentTrack} />
          
          <PlayerControls
            isPlaying={isPlaying}
            onPlay={() => handlePlay(currentTrack)}
            onPause={handlePause}
            onNext={handleNext}
            onSkip={handleSkip}
            player={player}
          />
        </div>

        {/* Audio Analysis Visualization */}
        <AudioAnalysis player={player} />

        {/* Queue Management */}
        <div className="queue-section">
          <div className="queue-header">
            <h2>Master Station Queue</h2>
            <button onClick={regenerateQueue}>Regenerate</button>
          </div>
          
          <PlaylistManager
            tracks={queue}
            currentTrack={currentTrack}
            onTrackSelect={handlePlay}
          />
        </div>

        {/* Community Features (Phase 2) */}
        {/* <CommunityFeed /> */}
      </main>
    </div>
  );
}

const NowPlaying = ({ track }) => {
  if (!track) return <div className="now-playing">No track playing</div>;

  return (
    <div className="now-playing">
      <img src={track.albumArt} alt={track.title} className="album-art" />
      <div className="track-info">
        <h2>{track.title}</h2>
        <p>{track.artist}</p>
        <span className="source-badge">{track.source}</span>
      </div>
    </div>
  );
};

const PlayerControls = ({ isPlaying, onPlay, onPause, onNext, onSkip, player }) => {
  const [volume, setVolume] = useState(0.8);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(player.getCurrentTime());
      setDuration(player.getDuration());
    }, 1000);

    return () => clearInterval(interval);
  }, [player]);

  const handleVolumeChange = (e) => {
    const newVolume = parseFloat(e.target.value);
    setVolume(newVolume);
    player.setVolume(newVolume);
  };

  const handleSeek = (e) => {
    const seekTime = parseFloat(e.target.value);
    player.seek(seekTime);
  };

  return (
    <div className="player-controls">
      {/* Progress bar */}
      <input
        type="range"
        min="0"
        max={duration}
        value={currentTime}
        onChange={handleSeek}
        className="progress-bar"
      />
      
      <div className="control-buttons">
        <button onClick={onSkip} className="btn-skip">Skip</button>
        
        {isPlaying ? (
          <button onClick={onPause} className="btn-pause">Pause</button>
        ) : (
          <button onClick={onPlay} className="btn-play">Play</button>
        )}
        
        <button onClick={onNext} className="btn-next">Next</button>
      </div>

      {/* Volume control */}
      <div className="volume-control">
        <input
          type="range"
          min="0"
          max="1"
          step="0.01"
          value={volume}
          onChange={handleVolumeChange}
        />
      </div>
    </div>
  );
};

const SourceSelector = ({ activeSource, onSourceChange }) => {
  const sources = ['spotify', 'youtube', 'local', 'cloud'];

  return (
    <div className="source-selector">
      {sources.map(source => (
        <button
          key={source}
          className={activeSource === source ? 'active' : ''}
          onClick={() => onSourceChange(source)}
        >
          {source}
        </button>
      ))}
    </div>
  );
};

export default App;
