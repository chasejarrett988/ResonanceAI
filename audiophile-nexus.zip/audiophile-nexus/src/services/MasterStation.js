/**
 * MasterStation - Adaptive playlist generation based on listening habits
 * Learns from user behavior and automatically curates personalized queues
 */

class MasterStation {
  constructor(database) {
    this.db = database;
    this.listeningHistory = [];
    this.userPreferences = {
      timeOfDay: {},
      genres: {},
      artists: {},
      skipPatterns: []
    };
  }

  /**
   * Record listening event for learning
   */
  async recordListenEvent(track, eventType, timestamp = Date.now()) {
    // eventType: 'play', 'skip', 'complete', 'repeat'
    
    const event = {
      trackId: track.id,
      source: track.source,
      eventType: eventType,
      timestamp: timestamp,
      timeOfDay: new Date(timestamp).getHours(),
      duration: track.duration,
      listenDuration: this.getListenDuration(track)
    };

    // PSEUDOCODE: Store in database
    // await this.db.insert('listening_history', event)
    
    this.listeningHistory.push(event);
    this.updatePreferences(track, event);
  }

  /**
   * Update user preference weights based on behavior
   */
  updatePreferences(track, event) {
    const hour = new Date(event.timestamp).getHours();
    const weight = this.calculateEventWeight(event);

    // Time-of-day preferences
    if (!this.userPreferences.timeOfDay[hour]) {
      this.userPreferences.timeOfDay[hour] = {};
    }
    this.userPreferences.timeOfDay[hour][track.genre] = 
      (this.userPreferences.timeOfDay[hour][track.genre] || 0) + weight;

    // Genre preferences with exponential decay
    const decayedWeight = weight * Math.exp(-0.1 * this.getRecentListenCount(track.genre));
    this.userPreferences.genres[track.genre] = 
      (this.userPreferences.genres[track.genre] || 0) + decayedWeight;

    // Artist preferences
    this.userPreferences.artists[track.artist] = 
      (this.userPreferences.artists[track.artist] || 0) + weight;

    // Track skip patterns (negative signal)
    if (event.eventType === 'skip') {
      this.userPreferences.skipPatterns.push({
        trackId: track.id,
        reason: this.inferSkipReason(track, event)
      });
    }
  }

  /**
   * Calculate weight for a listening event
   */
  calculateEventWeight(event) {
    const baseWeights = {
      'complete': 1.0,
      'repeat': 1.5,
      'play': 0.5,
      'skip': -0.8
    };

    let weight = baseWeights[event.eventType] || 0;

    // Bonus for longer listen duration
    if (event.listenDuration && event.duration) {
      const listenRatio = event.listenDuration / event.duration;
      weight *= listenRatio;
    }

    // Recency boost (exponential decay over 30 days)
    const daysSince = (Date.now() - event.timestamp) / (1000 * 60 * 60 * 24);
    const recencyMultiplier = Math.exp(-daysSince / 30);
    weight *= recencyMultiplier;

    return weight;
  }

  /**
   * Generate personalized queue based on current context
   */
  async generateQueue(seedTrack = null, queueLength = 50) {
    const currentHour = new Date().getHours();
    const candidates = await this.getCandidateTracks();

    // Score each candidate track
    const scoredTracks = candidates.map(track => ({
      track: track,
      score: this.scoreTrack(track, seedTrack, currentHour)
    }));

    // Sort by score and add diversity
    scoredTracks.sort((a, b) => b.score - a.score);
    const diverseQueue = this.addDiversity(scoredTracks, queueLength);

    return diverseQueue.map(item => item.track);
  }

  /**
   * Score a track for queue inclusion
   */
  scoreTrack(track, seedTrack, currentHour) {
    let score = 0;

    // Genre preference score
    const genreScore = this.userPreferences.genres[track.genre] || 0;
    score += genreScore * 0.4;

    // Artist preference score
    const artistScore = this.userPreferences.artists[track.artist] || 0;
    score += artistScore * 0.3;

    // Time-of-day relevance
    const timeScore = this.userPreferences.timeOfDay[currentHour]?.[track.genre] || 0;
    score += timeScore * 0.2;

    // Similarity to seed track (if provided)
    if (seedTrack) {
      const similarityScore = this.calculateSimilarity(track, seedTrack);
      score += similarityScore * 0.1;
    }

    // Penalty for recently skipped tracks
    const skipPenalty = this.getSkipPenalty(track);
    score -= skipPenalty;

    return score;
  }

  /**
   * Calculate similarity between two tracks
   */
  calculateSimilarity(track1, track2) {
    let similarity = 0;

    // Same genre
    if (track1.genre === track2.genre) similarity += 0.4;

    // Same artist
    if (track1.artist === track2.artist) similarity += 0.3;

    // Similar BPM (tempo)
    const bpmDiff = Math.abs(track1.bpm - track2.bpm);
    if (bpmDiff < 10) similarity += 0.2;

    // Similar energy/mood (pseudocode)
    // const energyDiff = Math.abs(track1.energy - track2.energy);
    // if (energyDiff < 0.2) similarity += 0.1;

    return similarity;
  }

  /**
   * Add diversity to prevent genre/artist clustering
   */
  addDiversity(scoredTracks, queueLength) {
    const queue = [];
    const usedArtists = new Set();
    const usedGenres = new Set();

    for (const item of scoredTracks) {
      if (queue.length >= queueLength) break;

      // Diversity rules:
      // - No more than 2 consecutive tracks from same artist
      // - No more than 3 consecutive tracks from same genre
      
      const lastTwo = queue.slice(-2);
      const lastThree = queue.slice(-3);

      const artistRepeat = lastTwo.every(t => t.track.artist === item.track.artist);
      const genreRepeat = lastThree.every(t => t.track.genre === item.track.genre);

      if (!artistRepeat && !genreRepeat) {
        queue.push(item);
        usedArtists.add(item.track.artist);
        usedGenres.add(item.track.genre);
      }
    }

    return queue;
  }

  /**
   * Collaborative filtering - find similar users
   */
  async findSimilarUsers(userId, limit = 10) {
    // PSEUDOCODE: Query database for users with similar listening patterns
    // const users = await this.db.query(`
    //   SELECT user_id, similarity_score
    //   FROM user_similarity
    //   WHERE source_user_id = ?
    //   ORDER BY similarity_score DESC
    //   LIMIT ?
    // `, [userId, limit])
    
    return []; // Return similar user IDs
  }

  /**
   * Get track recommendations from similar users
   */
  async getCollaborativeRecommendations(userId) {
    const similarUsers = await this.findSimilarUsers(userId);
    
    // PSEUDOCODE: Get tracks that similar users loved but current user hasn't heard
    // const recommendations = await this.db.query(`
    //   SELECT track_id, COUNT(*) as popularity
    //   FROM listening_history
    //   WHERE user_id IN (?) AND event_type IN ('complete', 'repeat')
    //   AND track_id NOT IN (
    //     SELECT track_id FROM listening_history WHERE user_id = ?
    //   )
    //   GROUP BY track_id
    //   ORDER BY popularity DESC
    // `, [similarUsers, userId])
    
    return [];
  }

  // Helper methods
  getListenDuration(track) {
    // Calculate how long user actually listened
    return 0; // Implement with actual timing
  }

  getRecentListenCount(genre) {
    const recentCutoff = Date.now() - (7 * 24 * 60 * 60 * 1000); // 7 days
    return this.listeningHistory.filter(
      event => event.timestamp > recentCutoff && event.genre === genre
    ).length;
  }

  inferSkipReason(track, event) {
    // PSEUDOCODE: ML model to infer why user skipped
    // Possible reasons: tempo mismatch, mood mismatch, overplayed, etc.
    return 'unknown';
  }

  getSkipPenalty(track) {
    const recentSkips = this.userPreferences.skipPatterns.filter(
      skip => skip.trackId === track.id && 
      (Date.now() - skip.timestamp) < (7 * 24 * 60 * 60 * 1000)
    );
    return recentSkips.length * 0.5;
  }

  async getCandidateTracks() {
    // PSEUDOCODE: Get all available tracks from all sources
    // return await this.db.query('SELECT * FROM tracks WHERE ...')
    return [];
  }
}

export default MasterStation;
