/**
 * MASTER STATION ALGORITHM
 * Adaptive playlist generation based on listening habits
 */

class MasterStation {
  constructor(database, userId) {
    this.db = database
    this.userId = userId
    this.habitWeights = {
      recent: 0.5,        // Weight for recent plays
      frequency: 0.3,     // Weight for play frequency
      completion: 0.1,    // Weight for completion rate
      timeOfDay: 0.1      // Weight for time-of-day patterns
    }
    this.decayRate = 0.95 // Exponential decay for older listens
  }

  // Get next recommended track
  async getNextTrack() {
    const habits = await this.analyzeHabits()
    const candidates = await this.getCandidateTracks(habits)
    const scored = this.scoreAndRank(candidates, habits)
    
    return scored[0] // Return highest scored track
  }

  // Analyze user listening patterns
  async analyzeHabits() {
    const playbackHistory = await this.db.getPlaybackHistory(this.userId, {
      limit: 500,
      includeSkipped: true
    })

    const habits = {
      topGenres: this.extractTopGenres(playbackHistory),
      topArtists: this.extractTopArtists(playbackHistory),
      avgSessionLength: this.calculateAvgSessionLength(playbackHistory),
      timeOfDayPatterns: this.analyzeTimePatterns(playbackHistory),
      energyPreference: this.analyzeEnergyLevels(playbackHistory),
      recentTrends: this.getRecentTrends(playbackHistory)
    }

    return habits
  }

  extractTopGenres(history) {
    const genreCounts = {}
    const now = Date.now()

    history.forEach(play => {
      const ageInDays = (now - play.timestamp) / (1000 * 60 * 60 * 24)
      const weight = Math.pow(this.decayRate, ageInDays)

      play.track.genres.forEach(genre => {
        genreCounts[genre] = (genreCounts[genre] || 0) + weight
      })
    })

    return Object.entries(genreCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([genre]) => genre)
  }

  extractTopArtists(history) {
    const artistScores = {}
    const now = Date.now()

    history.forEach(play => {
      const ageInDays = (now - play.timestamp) / (1000 * 60 * 60 * 24)
      const weight = Math.pow(this.decayRate, ageInDays)
      
      // Bonus weight for completed tracks
      const completionBonus = play.completed ? 1.5 : 0.5

      const score = weight * completionBonus
      artistScores[play.track.artist] = (artistScores[play.track.artist] || 0) + score
    })

    return Object.entries(artistScores)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([artist]) => artist)
  }

  analyzeTimePatterns(history) {
    const hourlyPreferences = Array(24).fill(0).map(() => ({
      genres: {},
      energy: [],
      count: 0
    }))

    history.forEach(play => {
      const hour = new Date(play.timestamp).getHours()
      hourlyPreferences[hour].count++
      
      play.track.genres.forEach(genre => {
        hourlyPreferences[hour].genres[genre] = 
          (hourlyPreferences[hour].genres[genre] || 0) + 1
      })

      if (play.track.energy) {
        hourlyPreferences[hour].energy.push(play.track.energy)
      }
    })

    // Calculate average energy per hour
    hourlyPreferences.forEach(hour => {
      if (hour.energy.length > 0) {
        hour.avgEnergy = hour.energy.reduce((a, b) => a + b) / hour.energy.length
      }
    })

    return hourlyPreferences
  }

  analyzeEnergyLevels(history) {
    const energyLevels = history
      .filter(play => play.completed && play.track.energy)
      .map(play => play.track.energy)

    if (energyLevels.length === 0) return 0.5

    const avgEnergy = energyLevels.reduce((a, b) => a + b) / energyLevels.length
    return avgEnergy
  }

  calculateAvgSessionLength(history) {
    // Group plays into sessions (gap > 30 minutes = new session)
    const sessions = []
    let currentSession = []

    history.forEach((play, i) => {
      if (i === 0) {
        currentSession.push(play)
      } else {
        const timeSinceLast = play.timestamp - history[i - 1].timestamp
        if (timeSinceLast > 30 * 60 * 1000) {
          sessions.push(currentSession)
          currentSession = [play]
        } else {
          currentSession.push(play)
        }
      }
    })

    if (currentSession.length > 0) sessions.push(currentSession)

    const avgLength = sessions.reduce((sum, session) => sum + session.length, 0) / sessions.length
    return avgLength
  }

  getRecentTrends(history) {
    const recentPlays = history.slice(0, 50)
    const olderPlays = history.slice(50, 200)

    const recentGenres = this.extractTopGenres(recentPlays)
    const olderGenres = this.extractTopGenres(olderPlays)

    // Find emerging genres
    const emerging = recentGenres.filter(g => !olderGenres.includes(g))

    return {
      emerging: emerging,
      stable: recentGenres.filter(g => olderGenres.includes(g))
    }
  }

  // Get candidate tracks for recommendation
  async getCandidateTracks(habits) {
    const candidates = []

    // Get tracks from top genres
    for (const genre of habits.topGenres) {
      const tracks = await this.db.getTracksByGenre(genre, { limit: 20 })
      candidates.push(...tracks)
    }

    // Get tracks from top artists
    for (const artist of habits.topArtists) {
      const tracks = await this.db.getTracksByArtist(artist, { limit: 10 })
      candidates.push(...tracks)
    }

    // Get similar tracks to recently played
    const recentFavorites = await this.db.getRecentFavorites(this.userId, { limit: 5 })
    for (const favorite of recentFavorites) {
      const similar = await this.getSimilarTracks(favorite)
      candidates.push(...similar)
    }

    // Remove duplicates and already played tracks
    const uniqueCandidates = this.deduplicateTracks(candidates)
    const unplayed = await this.filterUnplayed(uniqueCandidates)

    return unplayed
  }

  // Score and rank candidates
  scoreAndRank(candidates, habits) {
    const currentHour = new Date().getHours()
    const timePatterns = habits.timeOfDayPatterns[currentHour]

    const scored = candidates.map(track => {
      let score = 0

      // Genre match score
      const genreScore = track.genres.filter(g => habits.topGenres.includes(g)).length * 10
      score += genreScore * this.habitWeights.frequency

      // Artist match score
      const artistScore = habits.topArtists.includes(track.artist) ? 15 : 0
      score += artistScore * this.habitWeights.frequency

      // Time-of-day energy match
      if (track.energy && timePatterns.avgEnergy) {
        const energyDiff = Math.abs(track.energy - timePatterns.avgEnergy)
        const energyScore = (1 - energyDiff) * 10
        score += energyScore * this.habitWeights.timeOfDay
      }

      // Emerging trend bonus
      const trendBonus = track.genres.some(g => habits.recentTrends.emerging.includes(g)) ? 5 : 0
      score += trendBonus

      // Quality bonus (prefer high quality when available)
      if (track.bitrate >= 320) score += 3
      if (track.sampleRate >= 44100) score += 2

      // Add randomness to prevent staleness (±10%)
      score *= (0.9 + Math.random() * 0.2)

      return { track, score }
    })

    return scored.sort((a, b) => b.score - a.score).map(s => s.track)
  }

  async getSimilarTracks(track) {
    // Use collaborative filtering or audio features similarity
    const similar = await this.db.query(`
      SELECT * FROM tracks
      WHERE genres && $1
      AND artist != $2
      AND id NOT IN (
        SELECT track_id FROM playback_history WHERE user_id = $3
      )
      LIMIT 10
    `, [track.genres, track.artist, this.userId])

    return similar
  }

  deduplicateTracks(tracks) {
    const seen = new Set()
    return tracks.filter(track => {
      const key = `${track.artist}-${track.title}`
      if (seen.has(key)) return false
      seen.add(key)
      return true
    })
  }

  async filterUnplayed(tracks) {
    const playedIds = await this.db.getPlayedTrackIds(this.userId)
    return tracks.filter(track => !playedIds.includes(track.id))
  }

  // Update weights based on user feedback
  async updateWeights(feedback) {
    // If user skips a lot, reduce frequency weight, increase recent weight
    const skipRate = feedback.skipped / feedback.total
    
    if (skipRate > 0.3) {
      this.habitWeights.recent += 0.05
      this.habitWeights.frequency -= 0.05
    }

    // If user completes most tracks, current weights are good
    if (feedback.completionRate > 0.8) {
      // Weights are working well, don't change
    }

    // Normalize weights to sum to 1.0
    const total = Object.values(this.habitWeights).reduce((a, b) => a + b)
    Object.keys(this.habitWeights).forEach(key => {
      this.habitWeights[key] /= total
    })
  }
}

export default MasterStation
