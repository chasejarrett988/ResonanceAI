/**
 * DATABASE SCHEMA
 * PostgreSQL schema for Audiophile Nexus
 */

-- ============================================
-- USERS TABLE
-- ============================================
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) UNIQUE NOT NULL,
  username VARCHAR(100) UNIQUE NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  spotify_token TEXT,
  youtube_token TEXT,
  preferences JSONB DEFAULT '{}',
  master_station_weights JSONB DEFAULT '{"recent":0.5,"frequency":0.3,"completion":0.1,"timeOfDay":0.1}'
);

-- ============================================
-- TRACKS TABLE
-- ============================================
CREATE TABLE tracks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source VARCHAR(20) NOT NULL, -- 'spotify', 'youtube', 'local', 'cloud'
  source_id VARCHAR(255), -- External ID from Spotify/YouTube
  title VARCHAR(500) NOT NULL,
  artist VARCHAR(500) NOT NULL,
  album VARCHAR(500),
  duration INTEGER, -- in seconds
  genres TEXT[], -- Array of genre strings
  energy FLOAT, -- 0.0 to 1.0
  tempo INTEGER, -- BPM
  
  -- Audio quality metadata
  codec VARCHAR(50),
  bitrate INTEGER, -- in kbps
  sample_rate INTEGER, -- in Hz
  
  -- File location
  file_path TEXT, -- For local files
  cloud_url TEXT, -- For cloud storage
  
  -- Timestamps
  added_at TIMESTAMP DEFAULT NOW(),
  
  -- Full text search
  search_vector tsvector GENERATED ALWAYS AS (
    to_tsvector('english', title || ' ' || artist || ' ' || COALESCE(album, ''))
  ) STORED
);

CREATE INDEX idx_tracks_source ON tracks(source);
CREATE INDEX idx_tracks_artist ON tracks(artist);
CREATE INDEX idx_tracks_genres ON tracks USING GIN(genres);
CREATE INDEX idx_tracks_search ON tracks USING GIN(search_vector);

-- ============================================
-- PLAYBACK HISTORY TABLE
-- ============================================
CREATE TABLE playback_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  track_id UUID REFERENCES tracks(id) ON DELETE CASCADE,
  
  -- Playback metadata
  timestamp TIMESTAMP DEFAULT NOW(),
  time_of_day INTEGER, -- Hour 0-23
  duration_played INTEGER, -- Seconds played
  completed BOOLEAN DEFAULT false,
  skipped BOOLEAN DEFAULT false,
  
  -- Context
  source VARCHAR(20), -- Where track came from
  playlist_id UUID, -- If from playlist
  
  -- Quality at time of play
  quality_score INTEGER,
  bitrate_used INTEGER
);

CREATE INDEX idx_playback_user ON playback_history(user_id);
CREATE INDEX idx_playback_track ON playback_history(track_id);
CREATE INDEX idx_playback_timestamp ON playback_history(timestamp DESC);

-- ============================================
-- PLAYLISTS TABLE
-- ============================================
CREATE TABLE playlists (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  is_shared BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_playlists_user ON playlists(user_id);

-- ============================================
-- PLAYLIST TRACKS TABLE (Many-to-Many)
-- ============================================
CREATE TABLE playlist_tracks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  playlist_id UUID REFERENCES playlists(id) ON DELETE CASCADE,
  track_id UUID REFERENCES tracks(id) ON DELETE CASCADE,
  position INTEGER NOT NULL,
  added_at TIMESTAMP DEFAULT NOW(),
  
  UNIQUE(playlist_id, track_id)
);

CREATE INDEX idx_playlist_tracks_playlist ON playlist_tracks(playlist_id);
CREATE INDEX idx_playlist_tracks_position ON playlist_tracks(playlist_id, position);

-- ============================================
-- AUDIO SETUPS TABLE (Community Feature)
-- ============================================
CREATE TABLE audio_setups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  
  -- Equipment details
  equipment JSONB DEFAULT '{}', -- { headphones, dac, amp, speakers, etc. }
  settings JSONB DEFAULT '{}', -- EQ, filters, processing chain
  
  -- Social
  likes INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_setups_user ON audio_setups(user_id);
CREATE INDEX idx_setups_likes ON audio_setups(likes DESC);

-- ============================================
-- FAVORITES TABLE
-- ============================================
CREATE TABLE favorites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  track_id UUID REFERENCES tracks(id) ON DELETE CASCADE,
  added_at TIMESTAMP DEFAULT NOW(),
  
  UNIQUE(user_id, track_id)
);

CREATE INDEX idx_favorites_user ON favorites(user_id);

-- ============================================
-- LISTENING SESSIONS TABLE
-- ============================================
CREATE TABLE listening_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  start_time TIMESTAMP NOT NULL,
  end_time TIMESTAMP,
  track_count INTEGER DEFAULT 0,
  avg_quality_score FLOAT,
  total_duration INTEGER -- in seconds
);

CREATE INDEX idx_sessions_user ON listening_sessions(user_id);
CREATE INDEX idx_sessions_time ON listening_sessions(start_time DESC);

-- ============================================
-- VIEWS FOR ANALYTICS
-- ============================================

-- Top played tracks per user
CREATE VIEW user_top_tracks AS
SELECT 
  user_id,
  track_id,
  COUNT(*) as play_count,
  AVG(CASE WHEN completed THEN 1 ELSE 0 END) as completion_rate,
  MAX(timestamp) as last_played
FROM playback_history
GROUP BY user_id, track_id;

-- User listening habits by hour
CREATE VIEW user_hourly_habits AS
SELECT
  user_id,
  time_of_day,
  COUNT(*) as play_count,
  AVG(quality_score) as avg_quality,
  array_agg(DISTINCT t.genres) as genres
FROM playback_history ph
JOIN tracks t ON ph.track_id = t.id
GROUP BY user_id, time_of_day;

-- Track quality distribution
CREATE VIEW track_quality_stats AS
SELECT
  source,
  AVG(bitrate) as avg_bitrate,
  AVG(sample_rate) as avg_sample_rate,
  COUNT(*) as track_count
FROM tracks
WHERE bitrate IS NOT NULL
GROUP BY source;

-- ============================================
-- FUNCTIONS FOR COMMON QUERIES
-- ============================================

-- Get user's listening habits
CREATE OR REPLACE FUNCTION get_user_habits(p_user_id UUID)
RETURNS TABLE (
  top_genres TEXT[],
  top_artists TEXT[],
  avg_session_length INTEGER,
  favorite_time_of_day INTEGER,
  avg_quality_preference INTEGER
) AS $$
BEGIN
  RETURN QUERY
  WITH recent_plays AS (
    SELECT * FROM playback_history
    WHERE user_id = p_user_id
    AND timestamp > NOW() - INTERVAL '30 days'
  )
  SELECT
    (SELECT array_agg(DISTINCT unnest(t.genres))
     FROM recent_plays rp
     JOIN tracks t ON rp.track_id = t.id
     LIMIT 5) as top_genres,
    
    (SELECT array_agg(DISTINCT t.artist)
     FROM recent_plays rp
     JOIN tracks t ON rp.track_id = t.id
     GROUP BY t.artist
     ORDER BY COUNT(*) DESC
     LIMIT 10) as top_artists,
    
    (SELECT AVG(track_count)::INTEGER
     FROM listening_sessions
     WHERE user_id = p_user_id) as avg_session_length,
    
    (SELECT time_of_day
     FROM recent_plays
     GROUP BY time_of_day
     ORDER BY COUNT(*) DESC
     LIMIT 1) as favorite_time_of_day,
    
    (SELECT AVG(quality_score)::INTEGER
     FROM recent_plays) as avg_quality_preference;
END;
$$ LANGUAGE plpgsql;

-- Search tracks with full text search
CREATE OR REPLACE FUNCTION search_tracks(p_query TEXT)
RETURNS TABLE (
  id UUID,
  title VARCHAR,
  artist VARCHAR,
  album VARCHAR,
  source VARCHAR,
  rank REAL
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    t.id,
    t.title,
    t.artist,
    t.album,
    t.source,
    ts_rank(t.search_vector, query) as rank
  FROM tracks t,
       to_tsquery('english', p_query) query
  WHERE t.search_vector @@ query
  ORDER BY rank DESC
  LIMIT 50;
END;
$$ LANGUAGE plpgsql;
