/**
 * AUDIO ANALYSIS SERVICE
 * Real-time frequency analysis and quality metrics
 */

class AudioAnalysisService {
  constructor(analyserNode) {
    this.analyser = analyserNode
    this.sampleRate = analyserNode.context.sampleRate
    this.fftSize = analyserNode.fftSize
    this.binCount = analyserNode.frequencyBinCount
    this.nyquist = this.sampleRate / 2
  }

  // Calculate frequency for a given bin
  getFrequencyForBin(bin) {
    return (bin * this.nyquist) / this.binCount
  }

  // Get organized frequency bands
  getFrequencyBands() {
    const frequencyData = new Uint8Array(this.binCount)
    this.analyser.getByteFrequencyData(frequencyData)

    const bands = {
      subBass: { range: '20-60 Hz', value: 0 },      // 20-60 Hz
      bass: { range: '60-250 Hz', value: 0 },         // 60-250 Hz
      lowMids: { range: '250-500 Hz', value: 0 },     // 250-500 Hz
      mids: { range: '500-2k Hz', value: 0 },         // 500-2000 Hz
      highMids: { range: '2k-4k Hz', value: 0 },      // 2000-4000 Hz
      presence: { range: '4k-6k Hz', value: 0 },      // 4000-6000 Hz
      brilliance: { range: '6k-20k Hz', value: 0 }    // 6000-20000 Hz
    }

    // Calculate average amplitude for each band
    for (let i = 0; i < this.binCount; i++) {
      const freq = this.getFrequencyForBin(i)
      const amplitude = frequencyData[i]

      if (freq >= 20 && freq < 60) bands.subBass.value += amplitude
      else if (freq >= 60 && freq < 250) bands.bass.value += amplitude
      else if (freq >= 250 && freq < 500) bands.lowMids.value += amplitude
      else if (freq >= 500 && freq < 2000) bands.mids.value += amplitude
      else if (freq >= 2000 && freq < 4000) bands.highMids.value += amplitude
      else if (freq >= 4000 && freq < 6000) bands.presence.value += amplitude
      else if (freq >= 6000 && freq <= 20000) bands.brilliance.value += amplitude
    }

    // Normalize values (0-255 range to 0-100 percentage)
    Object.keys(bands).forEach(key => {
      bands[key].value = (bands[key].value / 255) * 100
    })

    return bands
  }

  // Calculate dynamic range
  getDynamicRange() {
    const timeDomainData = new Uint8Array(this.fftSize)
    this.analyser.getByteTimeDomainData(timeDomainData)

    let min = 255
    let max = 0

    for (let i = 0; i < timeDomainData.length; i++) {
      if (timeDomainData[i] < min) min = timeDomainData[i]
      if (timeDomainData[i] > max) max = timeDomainData[i]
    }

    // Dynamic range in dB (approximate)
    const range = max - min
    const dynamicRangeDB = 20 * Math.log10(range / 128)

    return {
      range: dynamicRangeDB,
      quality: this.assessDynamicRangeQuality(dynamicRangeDB)
    }
  }

  assessDynamicRangeQuality(rangeDB) {
    if (rangeDB > 60) return 'Excellent (Hi-Res)'
    if (rangeDB > 40) return 'Very Good (CD Quality)'
    if (rangeDB > 20) return 'Good (High Bitrate MP3)'
    if (rangeDB > 10) return 'Fair (Standard MP3)'
    return 'Poor (Over-compressed)'
  }

  // Estimate audio quality based on frequency content
  estimateQuality(track) {
    const frequencyData = new Uint8Array(this.binCount)
    this.analyser.getByteFrequencyData(frequencyData)

    // Check for high-frequency content (indicates quality)
    let highFreqPresence = 0
    for (let i = 0; i < this.binCount; i++) {
      const freq = this.getFrequencyForBin(i)
      if (freq > 15000) {
        highFreqPresence += frequencyData[i]
      }
    }

    const dynamicRange = this.getDynamicRange()

    return {
      codec: track.codec || 'Unknown',
      bitrate: track.bitrate || 'Unknown',
      sampleRate: track.sampleRate || this.sampleRate,
      dynamicRange: dynamicRange.range.toFixed(2) + ' dB',
      highFreqContent: highFreqPresence > 1000 ? 'Present' : 'Limited',
      estimatedQuality: this.calculateQualityScore(track, dynamicRange, highFreqPresence)
    }
  }

  calculateQualityScore(track, dynamicRange, highFreqPresence) {
    let score = 0

    // Bitrate contribution (40 points max)
    if (track.bitrate) {
      const bitrate = parseInt(track.bitrate)
      if (bitrate >= 320) score += 40
      else if (bitrate >= 256) score += 35
      else if (bitrate >= 192) score += 25
      else if (bitrate >= 128) score += 15
    }

    // Dynamic range contribution (40 points max)
    const rangeDB = dynamicRange.range
    if (rangeDB > 60) score += 40
    else if (rangeDB > 40) score += 30
    else if (rangeDB > 20) score += 20
    else if (rangeDB > 10) score += 10

    // High frequency content (20 points max)
    if (highFreqPresence > 2000) score += 20
    else if (highFreqPresence > 1000) score += 10
    else if (highFreqPresence > 500) score += 5

    return {
      score: score,
      rating: this.getQualityRating(score)
    }
  }

  getQualityRating(score) {
    if (score >= 90) return 'Master Quality'
    if (score >= 75) return 'Hi-Res'
    if (score >= 60) return 'CD Quality'
    if (score >= 40) return 'Good'
    if (score >= 20) return 'Fair'
    return 'Poor'
  }

  // Generate spectrum data for visualization
  getSpectrumVisualization() {
    const frequencyData = new Uint8Array(this.binCount)
    this.analyser.getByteFrequencyData(frequencyData)

    // Create logarithmic frequency bins for better visualization
    const visualBins = 64
    const spectrum = new Array(visualBins).fill(0)

    for (let i = 0; i < visualBins; i++) {
      // Logarithmic scale
      const binStart = Math.pow(2, (i / visualBins) * Math.log2(this.binCount))
      const binEnd = Math.pow(2, ((i + 1) / visualBins) * Math.log2(this.binCount))
      
      let sum = 0
      let count = 0
      
      for (let j = Math.floor(binStart); j < Math.floor(binEnd); j++) {
        sum += frequencyData[j]
        count++
      }
      
      spectrum[i] = count > 0 ? sum / count : 0
    }

    return spectrum
  }

  // Peak and RMS levels
  getLevels() {
    const timeDomainData = new Uint8Array(this.fftSize)
    this.analyser.getByteTimeDomainData(timeDomainData)

    let peak = 0
    let sumSquares = 0

    for (let i = 0; i < timeDomainData.length; i++) {
      const sample = (timeDomainData[i] - 128) / 128
      const abs = Math.abs(sample)
      
      if (abs > peak) peak = abs
      sumSquares += sample * sample
    }

    const rms = Math.sqrt(sumSquares / timeDomainData.length)

    return {
      peak: (peak * 100).toFixed(2) + '%',
      rms: (rms * 100).toFixed(2) + '%',
      peakDB: (20 * Math.log10(peak)).toFixed(2) + ' dB',
      rmsDB: (20 * Math.log10(rms)).toFixed(2) + ' dB'
    }
  }
}

export default AudioAnalysisService
