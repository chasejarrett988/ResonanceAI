/**
 * AudioAnalysis - Real-time audio visualization and quality metrics
 */

import React, { useEffect, useRef, useState } from 'react';

const AudioAnalysis = ({ player }) => {
  const canvasRef = useRef(null);
  const [metrics, setMetrics] = useState({
    bitrate: 0,
    sampleRate: 0,
    qualityScore: 0,
    dynamicRange: 0
  });

  useEffect(() => {
    if (!player || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let animationId;

    // Visualization loop
    const visualize = () => {
      const data = player.getAnalysisData();
      const quality = player.getQualityMetrics();

      // Update metrics
      setMetrics(quality);

      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Draw frequency spectrum
      drawFrequencySpectrum(ctx, data.frequency, canvas);

      // Draw waveform
      drawWaveform(ctx, data.timeDomain, canvas);

      animationId = requestAnimationFrame(visualize);
    };

    visualize();

    return () => cancelAnimationFrame(animationId);
  }, [player]);

  const drawFrequencySpectrum = (ctx, frequencyData, canvas) => {
    const barWidth = canvas.width / frequencyData.length;
    const barCount = frequencyData.length;

    ctx.fillStyle = '#00ff88'; // Neon green for spectrum

    for (let i = 0; i < barCount; i++) {
      const barHeight = (frequencyData[i] / 255) * (canvas.height / 2);
      const x = i * barWidth;
      const y = (canvas.height / 2) - barHeight;

      // Gradient effect
      const gradient = ctx.createLinearGradient(x, y, x, canvas.height / 2);
      gradient.addColorStop(0, '#00ff88');
      gradient.addColorStop(1, '#00aa55');
      ctx.fillStyle = gradient;

      ctx.fillRect(x, y, barWidth - 1, barHeight);
    }
  };

  const drawWaveform = (ctx, timeDomainData, canvas) => {
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#0088ff'; // Blue for waveform
    ctx.beginPath();

    const sliceWidth = canvas.width / timeDomainData.length;
    let x = 0;

    for (let i = 0; i < timeDomainData.length; i++) {
      const v = timeDomainData[i] / 255;
      const y = (v * canvas.height / 2) + (canvas.height / 2);

      if (i === 0) {
        ctx.moveTo(x, y);
      } else {
        ctx.lineTo(x, y);
      }

      x += sliceWidth;
    }

    ctx.stroke();
  };

  return (
    <div className="audio-analysis">
      <canvas 
        ref={canvasRef} 
        width={800} 
        height={400}
        style={{ width: '100%', background: '#0a0a0a', borderRadius: '8px' }}
      />
      
      <div className="quality-metrics">
        <MetricCard 
          label="Bitrate" 
          value={`${metrics.bitrate} kbps`}
          quality={metrics.bitrate >= 320 ? 'high' : 'medium'}
        />
        <MetricCard 
          label="Sample Rate" 
          value={`${(metrics.sampleRate / 1000).toFixed(1)} kHz`}
          quality={metrics.sampleRate >= 44100 ? 'high' : 'medium'}
        />
        <MetricCard 
          label="Quality Score" 
          value={`${metrics.qualityScore}/100`}
          quality={metrics.qualityScore >= 80 ? 'high' : 'medium'}
        />
        <MetricCard 
          label="Dynamic Range" 
          value={`${metrics.dynamicRange.toFixed(1)} dB`}
          quality={metrics.dynamicRange >= 10 ? 'high' : 'medium'}
        />
      </div>
    </div>
  );
};

const MetricCard = ({ label, value, quality }) => {
  const qualityColors = {
    high: '#00ff88',
    medium: '#ffaa00',
    low: '#ff4444'
  };

  return (
    <div className="metric-card">
      <div className="metric-label">{label}</div>
      <div 
        className="metric-value" 
        style={{ color: qualityColors[quality] }}
      >
        {value}
      </div>
    </div>
  );
};

export default AudioAnalysis;

/* 
CSS Pseudocode:
.audio-analysis {
  padding: 20px;
  background: #111;
  border-radius: 12px;
}

.quality-metrics {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
  margin-top: 20px;
}

.metric-card {
  background: #1a1a1a;
  padding: 16px;
  border-radius: 8px;
  text-align: center;
}

.metric-label {
  font-size: 12px;
  color: #888;
  text-transform: uppercase;
  letter-spacing: 1px;
}

.metric-value {
  font-size: 24px;
  font-weight: bold;
  margin-top: 8px;
  font-family: 'Monaco', monospace;
}
*/
