/**
 * UNIFIED PLAYER - Core playback orchestrator
 * Routes to appropriate service and maintains consistent audio context
 */

class UnifiedPlayer {
  constructor() {
    this.audioContext = new AudioContext({ sampleRate: 48000 })
    this.analyserNode = null
    this.currentSource = null // 'spotify' | 'youtube' | 'local' | 'cloud'
    this.currentTrack = null
    this.queue = []
    this.masterStation = null
  }

  // Initialize audio analysis chain
  initializeAudioChain() {
    this.analyserNode = this.audioContext.createAnalyser()
    this.analyserNode.fftSize = 8192 // High resolution for audiophile analysis
    this.analyserNode.smoothingTimeConstant = 0.8
    
    // Connect to destination
    this.analyserNode.connect(this.audioContext.destination)
  }

  // Play track from any source
  async play(track) {
    this.currentTrack = track
    this.currentSource = track.source

    switch(track.source) {
      case 'spotify':
        await this.playSpotify(track)
        break
      case 'youtube':
        await this.playYouTube(track)
        break
      case 'local':
        await this.playLocal(track)
        break
      case 'cloud':
        await this.playCloud(track)
        break
    }

    // Log playback for Master Station
    await this.logPlayback(track)
  }

  async playSpotify(track) {
    // Initialize Spotify Web Playback SDK
    const player = new Spotify.Player({
      name: 'Audiophile Nexus',
      getOAuthToken: cb => cb(getUserToken())
    })

    await player.connect()
    await player.play({ uris: [track.uri] })

    // Hook into Web Audio API for analysis
    const sourceNode = this.audioContext.createMediaElementSource(player._element)
    sourceNode.connect(this.analyserNode)
  }

  async playYouTube(track) {
    // Use ytdl-core or YouTube IFrame API
    const stream = await fetchYouTubeStream(track.videoId)
    
    const audioElement = new Audio()
    audioElement.src = stream.url
    
    const sourceNode = this.audioContext.createMediaElementSource(audioElement)
    sourceNode.connect(this.analyserNode)
    
    await audioElement.play()
  }

  async playLocal(track) {
    const audioElement = new Audio(track.filePath)
    
    const sourceNode = this.audioContext.createMediaElementSource(audioElement)
    sourceNode.connect(this.analyserNode)
    
    await audioElement.play()
  }

  async playCloud(track) {
    // Fetch from R2/S3
    const response = await fetch(track.cloudUrl, {
      headers: { 'Authorization': getCloudToken() }
    })
    
    const blob = await response.blob()
    const objectURL = URL.createObjectURL(blob)
    
    const audioElement = new Audio(objectURL)
    const sourceNode = this.audioContext.createMediaElementSource(audioElement)
    sourceNode.connect(this.analyserNode)
    
    await audioElement.play()
  }

  // Get real-time frequency data
  getFrequencyData() {
    const bufferLength = this.analyserNode.frequencyBinCount
    const dataArray = new Uint8Array(bufferLength)
    this.analyserNode.getByteFrequencyData(dataArray)
    return dataArray
  }

  // Get time domain data for waveform
  getTimeDomainData() {
    const bufferLength = this.analyserNode.fftSize
    const dataArray = new Uint8Array(bufferLength)
    this.analyserNode.getByteTimeDomainData(dataArray)
    return dataArray
  }

  // Queue management
  addToQueue(track) {
    this.queue.push(track)
  }

  async next() {
    if (this.queue.length > 0) {
      const nextTrack = this.queue.shift()
      await this.play(nextTrack)
    } else if (this.masterStation) {
      // Get next track from Master Station algorithm
      const recommended = await this.masterStation.getNextTrack()
      await this.play(recommended)
    }
  }

  // Log playback for habit learning
  async logPlayback(track) {
    const playbackData = {
      trackId: track.id,
      source: track.source,
      timestamp: Date.now(),
      timeOfDay: new Date().getHours(),
      duration: null, // Set on completion
      skipped: false,
      completed: false
    }

    await database.logPlayback(playbackData)
  }

  // Set up Master Station for adaptive playback
  setMasterStation(masterStation) {
    this.masterStation = masterStation
  }
}

export default UnifiedPlayer
