/**
 * PlaylistManager - Queue and playlist visualization
 */

import React, { useState } from 'react';

const PlaylistManager = ({ tracks, currentTrack, onTrackSelect }) => {
  const [filter, setFilter] = useState('');
  const [sortBy, setSortBy] = useState('position');

  const filteredTracks = tracks.filter(track =>
    track.title.toLowerCase().includes(filter.toLowerCase()) ||
    track.artist.toLowerCase().includes(filter.toLowerCase())
  );

  const sortedTracks = [...filteredTracks].sort((a, b) => {
    switch(sortBy) {
      case 'artist':
        return a.artist.localeCompare(b.artist);
      case 'title':
        return a.title.localeCompare(b.title);
      case 'duration':
        return a.duration - b.duration;
      default:
        return 0; // Keep original order
    }
  });

  return (
    <div className="playlist-manager">
      <div className="playlist-controls">
        <input
          type="text"
          placeholder="Filter tracks..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="search-input"
        />
        
        <select 
          value={sortBy} 
          onChange={(e) => setSortBy(e.target.value)}
          className="sort-select"
        >
          <option value="position">Queue Order</option>
          <option value="artist">Artist</option>
          <option value="title">Title</option>
          <option value="duration">Duration</option>
        </select>
      </div>

      <div className="track-list">
        {sortedTracks.map((track, index) => (
          <TrackRow
            key={track.id}
            track={track}
            index={index}
            isPlaying={currentTrack?.id === track.id}
            onSelect={() => onTrackSelect(track)}
          />
        ))}
      </div>
    </div>
  );
};

const TrackRow = ({ track, index, isPlaying, onSelect }) => {
  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div 
      className={`track-row ${isPlaying ? 'playing' : ''}`}
      onClick={onSelect}
    >
      <div className="track-position">{index + 1}</div>
      
      <img 
        src={track.albumArt || '/placeholder.png'} 
        alt={track.title}
        className="track-thumbnail"
      />
      
      <div className="track-details">
        <div className="track-title">{track.title}</div>
        <div className="track-artist">{track.artist}</div>
      </div>
      
      <div className="track-source">
        <SourceBadge source={track.source} />
      </div>
      
      <div className="track-duration">
        {formatDuration(track.duration)}
      </div>
      
      <div className="track-quality">
        <QualityIndicator bitrate={track.bitrate} />
      </div>
    </div>
  );
};

const SourceBadge = ({ source }) => {
  const colors = {
    spotify: '#1DB954',
    youtube: '#FF0000',
    local: '#888888',
    cloud: '#0088FF'
  };

  return (
    <span 
      className="source-badge"
      style={{ backgroundColor: colors[source] }}
    >
      {source}
    </span>
  );
};

const QualityIndicator = ({ bitrate }) => {
  const getQualityLevel = (bitrate) => {
    if (bitrate >= 320) return { level: 'Hi-Res', color: '#00ff88' };
    if (bitrate >= 192) return { level: 'High', color: '#ffaa00' };
    return { level: 'Standard', color: '#888888' };
  };

  const quality = getQualityLevel(bitrate);

  return (
    <span 
      className="quality-indicator"
      style={{ color: quality.color }}
    >
      {quality.level}
    </span>
  );
};

export default PlaylistManager;

/* 
CSS Pseudocode:
.playlist-manager {
  background: #1a1a1a;
  border-radius: 8px;
  padding: 20px;
}

.playlist-controls {
  display: flex;
  gap: 12px;
  margin-bottom: 20px;
}

.search-input {
  flex: 1;
  padding: 10px;
  background: #0a0a0a;
  border: 1px solid #333;
  border-radius: 4px;
  color: #fff;
}

.track-list {
  max-height: 600px;
  overflow-y: auto;
}

.track-row {
  display: grid;
  grid-template-columns: 40px 60px 1fr 100px 80px 100px;
  gap: 16px;
  padding: 12px;
  align-items: center;
  border-radius: 4px;
  cursor: pointer;
  transition: background 0.2s;
}

.track-row:hover {
  background: #222;
}

.track-row.playing {
  background: #1a3a1a;
}

.track-thumbnail {
  width: 50px;
  height: 50px;
  border-radius: 4px;
}

.track-title {
  font-weight: 600;
  color: #fff;
}

.track-artist {
  font-size: 14px;
  color: #888;
}

.source-badge {
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  color: #fff;
  text-transform: uppercase;
}
*/
