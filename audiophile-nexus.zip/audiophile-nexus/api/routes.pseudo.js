/**
 * API ROUTES
 * Express backend endpoints for music platform
 */

import express from 'express'
import UnifiedPlayer from '../components/UnifiedPlayer'
import MasterStation from '../services/MasterStation'
import AudioAnalysisService from '../analysis/AudioAnalysisService'

const router = express.Router()

// ============================================
// PLAYBACK ROUTES
// ============================================

// Play a track
router.post('/play', async (req, res) => {
  const { trackId, source } = req.body
  
  try {
    const track = await database.getTrack(trackId, source)
    await player.play(track)
    
    res.json({ success: true, track })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

// Pause playback
router.post('/pause', async (req, res) => {
  player.pause()
  res.json({ success: true })
})

// Skip to next track
router.post('/next', async (req, res) => {
  await player.next()
  res.json({ success: true, track: player.currentTrack })
})

// Add to queue
router.post('/queue/add', async (req, res) => {
  const { trackId, source } = req.body
  const track = await database.getTrack(trackId, source)
  player.addToQueue(track)
  res.json({ success: true, queue: player.queue })
})

// Get current queue
router.get('/queue', (req, res) => {
  res.json({ queue: player.queue })
})

// ============================================
// SEARCH & DISCOVERY ROUTES
// ============================================

// Unified search across all sources
router.get('/search', async (req, res) => {
  const { query, sources } = req.query
  
  const results = {
    spotify: [],
    youtube: [],
    local: [],
    cloud: []
  }
  
  if (sources.includes('spotify')) {
    results.spotify = await spotifySearch(query)
  }
  
  if (sources.includes('youtube')) {
    results.youtube = await youtubeSearch(query)
  }
  
  if (sources.includes('local')) {
    results.local = await localSearch(query)
  }
  
  if (sources.includes('cloud')) {
    results.cloud = await cloudSearch(query)
  }
  
  res.json(results)
})

async function spotifySearch(query) {
  // Call Spotify Web API
  const response = await fetch(`https://api.spotify.com/v1/search?q=${query}&type=track`, {
    headers: { 'Authorization': `Bearer ${getSpotifyToken()}` }
  })
  const data = await response.json()
  return data.tracks.items
}

async function youtubeSearch(query) {
  // Call YouTube Data API
  const response = await fetch(
    `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${query}&type=video&videoCategoryId=10`,
    { headers: { 'Authorization': `Bearer ${getYouTubeToken()}` } }
  )
  const data = await response.json()
  return data.items
}

async function localSearch(query) {
  return await database.searchLocal(query)
}

async function cloudSearch(query) {
  return await database.searchCloud(query)
}

// ============================================
// PLAYLIST ROUTES
// ============================================

// Create playlist
router.post('/playlists', async (req, res) => {
  const { name, tracks, userId } = req.body
  
  const playlist = await database.createPlaylist({
    name,
    userId,
    tracks,
    createdAt: Date.now()
  })
  
  res.json(playlist)
})

// Get user playlists
router.get('/playlists/:userId', async (req, res) => {
  const playlists = await database.getUserPlaylists(req.params.userId)
  res.json(playlists)
})

// Add track to playlist
router.post('/playlists/:playlistId/tracks', async (req, res) => {
  const { trackId, source } = req.body
  await database.addTrackToPlaylist(req.params.playlistId, trackId, source)
  res.json({ success: true })
})

// ============================================
// MASTER STATION ROUTES
// ============================================

// Get Master Station recommendations
router.get('/station/next/:userId', async (req, res) => {
  const masterStation = new MasterStation(database, req.params.userId)
  const nextTrack = await masterStation.getNextTrack()
  res.json(nextTrack)
})

// Get listening habits analysis
router.get('/habits/:userId', async (req, res) => {
  const masterStation = new MasterStation(database, req.params.userId)
  const habits = await masterStation.analyzeHabits()
  res.json(habits)
})

// Update Master Station weights
router.post('/station/feedback', async (req, res) => {
  const { userId, feedback } = req.body
  const masterStation = new MasterStation(database, userId)
  await masterStation.updateWeights(feedback)
  res.json({ success: true })
})

// ============================================
// AUDIO ANALYSIS ROUTES
// ============================================

// Get real-time frequency data
router.get('/analysis/frequency', (req, res) => {
  if (!analysisService) {
    return res.status(400).json({ error: 'No track playing' })
  }
  
  const bands = analysisService.getFrequencyBands()
  res.json(bands)
})

// Get audio quality metrics
router.get('/analysis/quality/:trackId', async (req, res) => {
  const track = await database.getTrack(req.params.trackId)
  const quality = analysisService.estimateQuality(track)
  res.json(quality)
})

// Get dynamic range analysis
router.get('/analysis/dynamic-range', (req, res) => {
  const dynamicRange = analysisService.getDynamicRange()
  res.json(dynamicRange)
})

// Get spectrum visualization data
router.get('/analysis/spectrum', (req, res) => {
  const spectrum = analysisService.getSpectrumVisualization()
  res.json(spectrum)
})

// Get peak/RMS levels
router.get('/analysis/levels', (req, res) => {
  const levels = analysisService.getLevels()
  res.json(levels)
})

// ============================================
// LIBRARY MANAGEMENT ROUTES
// ============================================

// Upload local file
router.post('/library/upload', async (req, res) => {
  const { file, metadata } = req.body
  
  // Save file to local storage or cloud
  const savedFile = await saveFile(file)
  
  // Extract metadata using music-metadata or similar
  const extractedMetadata = await extractMetadata(savedFile)
  
  const track = await database.addTrack({
    ...extractedMetadata,
    ...metadata,
    source: 'local',
    filePath: savedFile.path,
    addedAt: Date.now()
  })
  
  res.json(track)
})

// Sync with Spotify library
router.post('/library/sync/spotify', async (req, res) => {
  const { userId } = req.body
  const spotifyTracks = await fetchSpotifyLibrary(userId)
  
  for (const track of spotifyTracks) {
    await database.addTrack({
      ...track,
      source: 'spotify',
      userId
    })
  }
  
  res.json({ synced: spotifyTracks.length })
})

// ============================================
// COMMUNITY ROUTES
// ============================================

// Share audio setup
router.post('/community/setups', async (req, res) => {
  const { userId, setup } = req.body
  
  const sharedSetup = await database.createSharedSetup({
    userId,
    equipment: setup.equipment,
    settings: setup.settings,
    description: setup.description,
    createdAt: Date.now()
  })
  
  res.json(sharedSetup)
})

// Get community setups
router.get('/community/setups', async (req, res) => {
  const setups = await database.getSharedSetups({ limit: 50 })
  res.json(setups)
})

// Share playlist
router.post('/community/playlists/:playlistId/share', async (req, res) => {
  await database.sharePlaylist(req.params.playlistId)
  res.json({ success: true })
})

// ============================================
// USER ROUTES
// ============================================

// Get user profile
router.get('/users/:userId', async (req, res) => {
  const user = await database.getUser(req.params.userId)
  res.json(user)
})

// Update user preferences
router.put('/users/:userId/preferences', async (req, res) => {
  const { preferences } = req.body
  await database.updateUserPreferences(req.params.userId, preferences)
  res.json({ success: true })
})

export default router
