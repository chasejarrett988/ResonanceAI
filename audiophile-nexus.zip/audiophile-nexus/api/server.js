/**
 * API Server - Express backend for multi-source integration
 */

const express = require('express');
const cors = require('cors');
const sqlite3 = require('sqlite3').verbose();
const SpotifyWebApi = require('spotify-web-api-node');
const ytdl = require('ytdl-core');

const app = express();
app.use(cors());
app.use(express.json());

// Database initialization
const db = new sqlite3.Database('./audiophile.db');

// Initialize database schema
db.serialize(() => {
  // Users table
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    username TEXT UNIQUE,
    email TEXT UNIQUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Tracks table
  db.run(`CREATE TABLE IF NOT EXISTS tracks (
    id TEXT PRIMARY KEY,
    source TEXT,
    title TEXT,
    artist TEXT,
    album TEXT,
    genre TEXT,
    duration INTEGER,
    bitrate INTEGER,
    sample_rate INTEGER,
    codec TEXT,
    url TEXT,
    album_art TEXT,
    bpm INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Listening history
  db.run(`CREATE TABLE IF NOT EXISTS listening_history (
    id INTEGER PRIMARY KEY,
    user_id INTEGER,
    track_id TEXT,
    event_type TEXT,
    timestamp DATETIME,
    time_of_day INTEGER,
    listen_duration INTEGER,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(track_id) REFERENCES tracks(id)
  )`);

  // Playlists
  db.run(`CREATE TABLE IF NOT EXISTS playlists (
    id INTEGER PRIMARY KEY,
    user_id INTEGER,
    name TEXT,
    source TEXT,
    source_id TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user_id) REFERENCES users(id)
  )`);

  // Playlist tracks
  db.run(`CREATE TABLE IF NOT EXISTS playlist_tracks (
    playlist_id INTEGER,
    track_id TEXT,
    position INTEGER,
    FOREIGN KEY(playlist_id) REFERENCES playlists(id),
    FOREIGN KEY(track_id) REFERENCES tracks(id)
  )`);
});

// Spotify API client
const spotifyApi = new SpotifyWebApi({
  clientId: process.env.SPOTIFY_CLIENT_ID,
  clientSecret: process.env.SPOTIFY_CLIENT_SECRET,
  redirectUri: 'http://localhost:3000/callback'
});

// ===== ROUTES =====

// Spotify Authentication
app.get('/api/spotify/auth', (req, res) => {
  const scopes = ['user-read-private', 'user-read-email', 'streaming', 'user-read-playback-state'];
  res.redirect(spotifyApi.createAuthorizeURL(scopes));
});

app.get('/api/spotify/callback', async (req, res) => {
  const { code } = req.query;
  
  try {
    const data = await spotifyApi.authorizationCodeGrant(code);
    const { access_token, refresh_token } = data.body;
    
    spotifyApi.setAccessToken(access_token);
    spotifyApi.setRefreshToken(refresh_token);
    
    res.json({ access_token, refresh_token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get Spotify playlists
app.get('/api/spotify/playlists', async (req, res) => {
  try {
    const data = await spotifyApi.getUserPlaylists();
    res.json(data.body.items);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Search Spotify
app.get('/api/spotify/search', async (req, res) => {
  const { query, type = 'track' } = req.query;
  
  try {
    const data = await spotifyApi.search(query, [type]);
    res.json(data.body);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// YouTube Music search
app.get('/api/youtube/search', async (req, res) => {
  const { query } = req.query;
  
  // PSEUDOCODE: Implement YouTube Music API search
  // const results = await youtubeMusic.search(query);
  
  res.json({ message: 'YouTube search not yet implemented' });
});

// Get YouTube stream URL
app.get('/api/youtube/stream/:videoId', async (req, res) => {
  const { videoId } = req.params;
  
  try {
    const info = await ytdl.getInfo(videoId);
    const format = ytdl.chooseFormat(info.formats, { quality: 'highestaudio' });
    
    res.json({ 
      url: format.url,
      bitrate: format.audioBitrate,
      codec: format.audioCodec
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Upload local file metadata
app.post('/api/tracks/local', (req, res) => {
  const track = req.body;
  
  db.run(
    `INSERT INTO tracks (id, source, title, artist, album, genre, duration, bitrate, sample_rate, codec, url)
     VALUES (?, 'local', ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [track.id, track.title, track.artist, track.album, track.genre, 
     track.duration, track.bitrate, track.sampleRate, track.codec, track.url],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID });
    }
  );
});

// Get listening history
app.get('/api/history/:userId', (req, res) => {
  const { userId } = req.params;
  const { limit = 50 } = req.query;
  
  db.all(
    `SELECT h.*, t.title, t.artist, t.source
     FROM listening_history h
     JOIN tracks t ON h.track_id = t.id
     WHERE h.user_id = ?
     ORDER BY h.timestamp DESC
     LIMIT ?`,
    [userId, limit],
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    }
  );
});

// Record listening event
app.post('/api/history', (req, res) => {
  const { userId, trackId, eventType, timestamp, listenDuration } = req.body;
  const timeOfDay = new Date(timestamp).getHours();
  
  db.run(
    `INSERT INTO listening_history (user_id, track_id, event_type, timestamp, time_of_day, listen_duration)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [userId, trackId, eventType, timestamp, timeOfDay, listenDuration],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID });
    }
  );
});

// Create playlist
app.post('/api/playlists', (req, res) => {
  const { userId, name, source, sourceId } = req.body;
  
  db.run(
    `INSERT INTO playlists (user_id, name, source, source_id)
     VALUES (?, ?, ?, ?)`,
    [userId, name, source, sourceId],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ id: this.lastID });
    }
  );
});

// Get user playlists
app.get('/api/playlists/:userId', (req, res) => {
  const { userId } = req.params;
  
  db.all(
    `SELECT * FROM playlists WHERE user_id = ?`,
    [userId],
    (err, rows) => {
      if (err) return res.status(500).json({ error: err.message });
      res.json(rows);
    }
  );
});

// Add track to playlist
app.post('/api/playlists/:playlistId/tracks', (req, res) => {
  const { playlistId } = req.params;
  const { trackId, position } = req.body;
  
  db.run(
    `INSERT INTO playlist_tracks (playlist_id, track_id, position)
     VALUES (?, ?, ?)`,
    [playlistId, trackId, position],
    function(err) {
      if (err) return res.status(500).json({ error: err.message });
      res.json({ success: true });
    }
  );
});

// Get Master Station queue
app.get('/api/master-station/:userId', async (req, res) => {
  const { userId } = req.params;
  const { seedTrackId } = req.query;
  
  // PSEUDOCODE: Use MasterStation algorithm
  // const masterStation = new MasterStation(db);
  // const queue = await masterStation.generateQueue(seedTrackId, 50);
  
  res.json({ queue: [] });
});

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`API server running on port ${PORT}`);
});

module.exports = app;
