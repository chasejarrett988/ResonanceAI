/**
 * CONFIGURATION
 * Environment variables and app config
 */

export const config = {
  // Server
  port: process.env.PORT || 3000,
  nodeEnv: process.env.NODE_ENV || 'development',
  
  // Database
  database: {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    name: process.env.DB_NAME || 'audiophile_nexus',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD,
    ssl: process.env.DB_SSL === 'true'
  },
  
  // Spotify API
  spotify: {
    clientId: process.env.SPOTIFY_CLIENT_ID,
    clientSecret: process.env.SPOTIFY_CLIENT_SECRET,
    redirectUri: process.env.SPOTIFY_REDIRECT_URI || 'http://localhost:3000/auth/spotify/callback',
    scopes: [
      'user-read-playback-state',
      'user-modify-playback-state',
      'user-read-currently-playing',
      'streaming',
      'user-library-read',
      'playlist-read-private',
      'playlist-read-collaborative'
    ]
  },
  
  // YouTube API
  youtube: {
    apiKey: process.env.YOUTUBE_API_KEY,
    clientId: process.env.YOUTUBE_CLIENT_ID,
    clientSecret: process.env.YOUTUBE_CLIENT_SECRET
  },
  
  // Cloud Storage (R2/S3)
  storage: {
    provider: process.env.STORAGE_PROVIDER || 'r2', // 'r2' or 's3'
    accountId: process.env.CF_ACCOUNT_ID,
    accessKeyId: process.env.STORAGE_ACCESS_KEY,
    secretAccessKey: process.env.STORAGE_SECRET_KEY,
    bucket: process.env.STORAGE_BUCKET || 'audiophile-nexus',
    region: process.env.STORAGE_REGION || 'auto',
    endpoint: process.env.STORAGE_ENDPOINT
  },
  
  // Audio Processing
  audio: {
    maxBitrate: 320, // kbps
    preferredSampleRate: 48000, // Hz
    fftSize: 8192,
    smoothingTimeConstant: 0.8,
    maxUploadSize: 100 * 1024 * 1024 // 100MB
  },
  
  // Master Station
  masterStation: {
    historyLimit: 500, // Tracks to analyze
    decayRate: 0.95, // Exponential decay for older plays
    updateInterval: 3600000, // Update weights every hour (ms)
    minTrackScore: 0, // Minimum score for recommendations
    defaultWeights: {
      recent: 0.5,
      frequency: 0.3,
      completion: 0.1,
      timeOfDay: 0.1
    }
  },
  
  // Session Management
  session: {
    secret: process.env.SESSION_SECRET,
    maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    gapThreshold: 30 * 60 * 1000 // 30 minutes = new session
  },
  
  // Rate Limiting
  rateLimit: {
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100 // requests per window
  },
  
  // CORS
  cors: {
    origin: process.env.CORS_ORIGIN || 'http://localhost:5173',
    credentials: true
  },
  
  // Features
  features: {
    communitySharing: true,
    cloudUpload: true,
    audioAnalysis: true,
    masterStation: true
  }
}

export default config
